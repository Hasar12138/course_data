#!/usr/bin/env python
import rospy
import cv2

def show_wanted_image():
    # Load the wanted image
    img_path = '/home/user/catkin_ws/src/opencv_for_robotics_images/Project/Course_images/wanted.png'
    img = cv2.imread(img_path)

    if img is None:
        rospy.logerr("Failed to load the image!")
        return

    # Display the image in a window
    rospy.loginfo("Displaying wanted image...")
    while not rospy.is_shutdown():
        cv2.imshow("Wanted Person", img)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Close the window when done
    cv2.destroyAllWindows()

if __name__ == '__main__':
    rospy.init_node('display_wanted', anonymous=True)
    try:
        show_wanted_image()
    except rospy.ROSInterruptException:
        pass
