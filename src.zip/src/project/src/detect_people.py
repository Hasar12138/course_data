#!/usr/bin/env python
import rospy
from sensor_msgs.msg import LaserScan

def people_detector(scan_data):
    # Assume people are closer than 1.5 meters
    threshold_distance = 1.5
    for i, distance in enumerate(scan_data.ranges):
        if distance < threshold_distance:
            rospy.loginfo(f"Person detected at angle {i} with distance {distance:.2f} meters")

def detect_people():
    rospy.init_node('detect_people', anonymous=True)
    rospy.Subscriber('/scan', LaserScan, people_detector)
    rospy.spin()

if __name__ == '__main__':
    try:
        detect_people()
    except rospy.ROSInterruptException:
        pass
