#!/usr/bin/env python

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from cv2 import aruco

def order_coordinates(pts):
    # Initialize an empty array to save the next values
    coordinates = np.zeros((4, 2), dtype="int")

    s = pts.sum(axis=1)
    coordinates[0] = pts[np.argmin(s)]  # Top-left
    coordinates[2] = pts[np.argmax(s)]  # Bottom-right

    diff = np.diff(pts, axis=1)
    coordinates[1] = pts[np.argmin(diff)]  # Top-right
    coordinates[3] = pts[np.argmax(diff)]  # Bottom-left

    return coordinates

class ArUcoDetector:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('aruco_detector', anonymous=True)

        # Create a CvBridge object to convert between ROS and OpenCV images
        self.bridge = CvBridge()

        # Subscribe to the robot's camera topic
        self.image_sub = rospy.Subscriber('/camera/rgb/image_raw', Image, self.image_callback)

        # Initialize the aruco Dictionary and detector parameters
        self.aruco_dict = aruco.Dictionary_get(aruco.DICT_6X6_250)
        self.parameters = aruco.DetectorParameters_create()

        rospy.loginfo("ArUco detector initialized...")

    def image_callback(self, data):
        try:
            # Convert the ROS Image message to a format OpenCV can work with
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")

            # Resize the image to make processing faster
            h, w = cv_image.shape[:2]
            cv_image = cv2.resize(cv_image, (int(w * 0.7), int(h * 0.7)))

            # Convert the image to grayscale
            gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

            # Detect ArUco markers
            corners, ids, _ = aruco.detectMarkers(gray, self.aruco_dict, parameters=self.parameters)

            if ids is not None:
                # Draw detected markers on the image
                frame_markers = aruco.drawDetectedMarkers(cv_image.copy(), corners, ids)

                # Display the markers on screen
                cv2.imshow('markers', frame_markers)

                # Initialize an empty list to store the center points of each corner
                params = []

                for i in range(len(ids)):
                    # Get the corners of the current tag
                    c = corners[i][0]

                    # Draw a circle at the center of each detected marker
                    cv2.circle(cv_image, (int(c[:, 0].mean()), int(c[:, 1].mean())), 3, (255, 255, 0), -1)

                    # Append the center coordinate to the params list
                    params.append((int(c[:, 0].mean()), int(c[:, 1].mean())))

                # Convert the list of points to a numpy array for further processing
                params = np.array(params)

                # Sort the coordinates
                if len(params) >= 4:
                    params = order_coordinates(params)

                # Draw a filled pink polygon with the ordered coordinates
                cv2.fillPoly(cv_image, [params], (255, 0, 150))

                # Display the image with the detected markers and filled pink polygon
                cv2.imshow('Ordered ArUco Detections', cv_image)
                cv2.waitKey(1)

        except Exception as e:
            rospy.logerr(f"Error processing image: {e}")

if __name__ == '__main__':
    try:
        # Start the ArUco detection
        ArUcoDetector()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass

    # Clean up windows
    cv2.destroyAllWindows()
