#include "ros/ros.h"

int main(int argc, char **argv)
{
    ros::init(argc, argv, "unit5_node");
    ros::NodeHandle nh;

    ROS_INFO("Unit 5 Node is running!");

    ros::spin();
    return 0;
}
