#!/usr/bin/env python

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

def callback(image_msg):
    # Convert the ROS Image message to a CV2 Image
    bridge = CvBridge()
    image = bridge.imgmsg_to_cv2(image_msg, "bgr8")
    
    # Resize the image for easier display
    image = cv2.resize(image, (300, 300))

    # Convert to HSV color space
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    # Define HSV color ranges for filtering
    # Adjust these values based on the specific shades you want to filter
    min_grass = np.array([30, 40, 40])
    max_grass = np.array([90, 255, 255])

    min_water = np.array([100, 150, 0])
    max_water = np.array([140, 255, 255])

    min_roof = np.array([0, 50, 50])
    max_roof = np.array([10, 255, 255])

    # Create masks for each color
    mask_grass = cv2.inRange(hsv, min_grass, max_grass)
    mask_water = cv2.inRange(hsv, min_water, max_water)
    mask_roof = cv2.inRange(hsv, min_roof, max_roof)

    # Apply masks to the original image
    res_grass = cv2.bitwise_and(image, image, mask=mask_grass)
    res_water = cv2.bitwise_and(image, image, mask=mask_water)
    res_roof = cv2.bitwise_and(image, image, mask=mask_roof)

    # Stack the images for display
    combined = np.hstack((image, res_grass, res_water, res_roof))
    
    # Display the images
    cv2.imshow("Original Image | Grass | Water | Roof", combined)
    cv2.waitKey(1)  # Add a delay to show the window

def main():
    # Initialize the ROS node
    rospy.init_node('color_filter2_node', anonymous=True)

    # Subscribe to the camera image topic
    rospy.Subscriber('/camera/rgb/image_raw', Image, callback)

    rospy.spin()  # Keep the node running

if __name__ == '__main__':
    main()
