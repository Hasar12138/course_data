#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import cv2
import numpy as np
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image

class MorphologicalTransformationsX:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('morphological_transformations_x_node', anonymous=True)
        rospy.loginfo("Morphological Transformations X Node has started")

        # Create a CvBridge object for converting ROS images to OpenCV images
        self.bridge = CvBridge()

        # Subscribe to the UAV camera image topic
        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw", Image, self.image_callback)

        # Define a kernel for morphological operations
        self.kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))

    def image_callback(self, data):
        try:
            # Convert ROS Image message to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(data, desired_encoding="bgr8")
        except CvBridgeError as e:
            rospy.logerr(f"CvBridge Error: {e}")
            return

        # Resize the image for consistent display
        resized_image = cv2.resize(cv_image, (600, 400))

        # Convert to grayscale
        gray_image = cv2.cvtColor(resized_image, cv2.COLOR_BGR2GRAY)

        # Apply Horizontal Sobel operator
        sobelx = cv2.Sobel(gray_image, cv2.CV_64F, 1, 0, ksize=5)
        sobelx = cv2.convertScaleAbs(sobelx)

        # Apply morphological operations to the Sobel image
        eroded = cv2.erode(sobelx, self.kernel, iterations=1)
        dilated = cv2.dilate(sobelx, self.kernel, iterations=1)
        opening = cv2.morphologyEx(sobelx, cv2.MORPH_OPEN, self.kernel)
        closing = cv2.morphologyEx(sobelx, cv2.MORPH_CLOSE, self.kernel)
        gradient = cv2.morphologyEx(sobelx, cv2.MORPH_GRADIENT, self.kernel)
        top_hat = cv2.morphologyEx(sobelx, cv2.MORPH_TOPHAT, self.kernel)
        black_hat = cv2.morphologyEx(sobelx, cv2.MORPH_BLACKHAT, self.kernel)

        # Display the images
        cv2.imshow('Grayscale Original Image', gray_image)
        cv2.imshow('Horizontal Sobel Image', sobelx)
        cv2.imshow('Eroded Sobel', eroded)
        cv2.imshow('Dilated Sobel', dilated)
        cv2.imshow('Opening on Sobel', opening)
        cv2.imshow('Closing on Sobel', closing)
        cv2.imshow('Morphological Gradient on Sobel', gradient)
        cv2.imshow('Top Hat on Sobel', top_hat)
        cv2.imshow('Black Hat on Sobel', black_hat)

        rospy.loginfo("Displaying Morphological Transformations on Horizontal Sobel Image. Press 'q' to exit.")

        # Handle OpenCV window events
        if cv2.waitKey(1) & 0xFF == ord('q'):
            rospy.signal_shutdown("User requested shutdown.")
    
    def run(self):
        try:
            rospy.spin()
        except KeyboardInterrupt:
            rospy.loginfo("Shutting down Morphological Transformations X Node")
        finally:
            cv2.destroyAllWindows()

if __name__ == '__main__':
    transformationsx_node = MorphologicalTransformationsX()
    transformationsx_node.run()
