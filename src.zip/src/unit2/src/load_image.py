#!/usr/bin/env python
import rospy
import cv2
import os
from cv_bridge import CvBridge
from sensor_msgs.msg import Image

class ImageLoader:
    def __init__(self):
        rospy.init_node('load_image_node', anonymous=True)
        self.bridge = CvBridge()

        # Subscribe to the camera image topic
        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw", Image, self.image_callback)

        # Path to the image to read
        self.image_path = '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_2/Course_images/test_image_1.jpg'

        # Read and show the image
        self.display_image()

    def image_callback(self, msg):
        # Convert the ROS Image message to OpenCV format
        try:
            camera_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            cv2.imshow("Camera Image", camera_image)
            cv2.waitKey(1)  # To allow the image window to refresh
        except Exception as e:
            rospy.logerr(f"Error converting image: {e}")

    def display_image(self):
        # Read the image file
        if os.path.exists(self.image_path):
            img = cv2.imread(self.image_path)
            cv2.imshow("Test Image", img)
            cv2.waitKey(0)  # Wait indefinitely until a key is pressed
            # Save the image from the camera feed
            cv2.imwrite('drone_image.jpg', img)
            rospy.loginfo("Saved image as drone_image.jpg")
        else:
            rospy.logerr(f"Image file not found at path: {self.image_path}")

if __name__ == '__main__':
    try:
        img_loader = ImageLoader()
        rospy.spin()
        cv2.destroyAllWindows()
    except rospy.ROSInterruptException:
        cv2.destroyAllWindows()
