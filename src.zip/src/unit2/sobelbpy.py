#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import cv2
import numpy as np

def main():
    # initialize the node
    rospy.init_node('sobel_node', anonymous=True)
    
    # open the camera
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        rospy.logerr("Fail to open")
        return
    
    rospy.loginfo("Sobel node has been activated. Please exit by pressing q")
    
    while not rospy.is_shutdown():
        ret, frame = cap.read()
        
        if not ret:
            rospy.logerr("Fail to recieve frames. Exiting...")
            break
        
        # convert the frame to grayscale image

        #img = cv2.imread('/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_2/Course_images/test_img_b.jpg')

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        #gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # horizen Sobel operator
        sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobelx = cv2.convertScaleAbs(sobelx)
        
        # vertical Sobel operator
        sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        sobely = cv2.convertScaleAbs(sobely)
        
        # show the original and processed image
        cv2.imshow('Original', frame)
        cv2.imshow('Sobel X', sobelx)
        cv2.imshow('Sobel Y', sobely)
        
        # exit by pressing q
        if cv2.waitKey(1) & 0xFF == ord('q'):
            rospy.signal_shutdown("request for exit")
            break
    
    # release the camera
    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
