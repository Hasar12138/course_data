#!/usr/bin/env python
# exercise4_2_2.py

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2
import numpy as np
import matplotlib.pyplot as plt

class WaterholeDetector:
    def __init__(self):
        self.bridge = CvBridge()
        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw", Image, self.callback)
        self.reference_image_path = '/home/user/catkin_ws/src/unit4/src/waterhole_cropped.png'  # Modify this to your path
        self.reference_image = cv2.imread(self.reference_image_path, cv2.IMREAD_GRAYSCALE)
        if self.reference_image is None:
            rospy.logerr("Reference image not found at {}".format(self.reference_image_path))
            rospy.signal_shutdown("Reference image not found.")
        self.orb = cv2.ORB_create(nfeatures=1000)
        self.bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
        self.train_keypoints, self.train_descriptor = self.orb.detectAndCompute(self.reference_image, None)
        rospy.loginfo("WaterholeDetector node initialized.")

        # Record the number of matches to evaluate the best value
        self.match_counts = []

    def evaluate_good_matches(self, matches, lower=4, upper=1000):
        """
        Evaluate whether the number of matches is within the specified range
        """
        count = len(matches)
        self.match_counts.append(count)
        rospy.loginfo("Number of good matches: {}".format(count))
        return lower <= count <= upper

    def callback(self, data):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            rospy.logerr(e)
            return

        gray_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

        # Detect keypoints and descriptors
        test_keypoints, test_descriptor = self.orb.detectAndCompute(gray_image, None)

        if test_descriptor is None:
            rospy.logwarn("No descriptors found in the test image.")
            return

        # Match descriptors
        matches = self.bf.match(self.train_descriptor, test_descriptor)
        matches = sorted(matches, key=lambda x: x.distance)

        # Dynamically select the number of good_matches
        good_matches = matches[:300]  # Initial value, can be adjusted based on evaluation results

        # Evaluate good_matches
        if not self.evaluate_good_matches(good_matches, lower=18, upper=1000):
            rospy.logwarn("Good matches count {} is out of the desired range.".format(len(good_matches)))
            # Adjust the number of good_matches as needed
            # For example, try different thresholds
            good_matches = matches[:200]

        # Draw keypoints
        img_keypoints = cv2.drawKeypoints(self.reference_image, self.train_keypoints, None, color=(0,255,0), flags=0)
        cv2.imshow('Reference Keypoints', img_keypoints)

        # Draw match results
        img_matches = cv2.drawMatches(self.reference_image, self.train_keypoints, cv_image, test_keypoints, good_matches, None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
        cv2.imshow('Matches', img_matches)

        # Calculate and display localization results
        if len(good_matches) > 10:
            src_pts = np.float32([self.train_keypoints[m.queryIdx].pt for m in good_matches]).reshape(-1,1,2)
            dst_pts = np.float32([test_keypoints[m.trainIdx].pt for m in good_matches]).reshape(-1,1,2)

            M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
            if M is not None:
                h, w = self.reference_image.shape
                pts = np.float32([[0,0], [0,h-1], [w-1,h-1], [w-1,0]]).reshape(-1,1,2)
                dst = cv2.perspectiveTransform(pts, M)
                cv2.polylines(cv_image, [np.int32(dst)], True, (50,0,255), 3, cv2.LINE_AA)
                cv2.imshow('Detection', cv_image)
            else:
                rospy.logwarn("Homography could not be computed.")
        else:
            rospy.logwarn("Not enough good matches to compute homography.")

        cv2.waitKey(1)

def main():
    detector = WaterholeDetector()
    rospy.init_node('waterhole_detector_node', anonymous=True)
    try:
        rospy.spin()
    except KeyboardInterrupt:
        rospy.loginfo("Shutting down WaterholeDetector node.")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
