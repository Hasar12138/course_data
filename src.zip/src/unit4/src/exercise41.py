#!/usr/bin/env python
# exercise4_1.py

import cv2
import matplotlib.pyplot as plt
import numpy as np

def main():
    # 1. Read and resize images
    image1_path = '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_4/Course_images/ROS.png'
    image2_path = '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_4/Course_images/ROS2.jpg'

    # Read the first image and resize to 400x600
    image_1 = cv2.imread(image1_path, cv2.IMREAD_COLOR)
    if image_1 is None:
        print("Unable to read image:", image1_path)
        return
    image_1 = cv2.resize(image_1, (600, 400))  # (width, height)

    # Read the second image and resize to 600x400
    image_2 = cv2.imread(image2_path, cv2.IMREAD_COLOR)
    if image_2 is None:
        print("Unable to read image:", image2_path)
        return
    image_2 = cv2.resize(image_2, (600, 400))  # (width, height)

    # Convert to grayscale
    gray_1 = cv2.cvtColor(image_1, cv2.COLOR_BGR2GRAY)
    gray_2 = cv2.cvtColor(image_2, cv2.COLOR_BGR2GRAY)

    # 2. Initialize ORB feature detector
    orb = cv2.ORB_create(nfeatures=1000)

    # 3. Copy the original images to display keypoints
    preview_1 = np.copy(image_1)
    preview_2 = np.copy(image_2)

    # Create another copy to show only the points
    dots = np.copy(image_1)

    # 4. Extract keypoints and descriptors
    keypoints_1, descriptors_1 = orb.detectAndCompute(gray_1, None)
    keypoints_2, descriptors_2 = orb.detectAndCompute(gray_2, None)

    # 5. Draw keypoints for the first image
    cv2.drawKeypoints(image_1, keypoints_1, preview_1, flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    cv2.imshow('ROS.png Keypoints', preview_1)

    # 6. Initialize Brute-Force Matcher
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

    # 7. Match descriptors
    if descriptors_1 is None or descriptors_2 is None:
        print("Unable to find descriptors.")
        return

    matches = bf.match(descriptors_1, descriptors_2)

    # 8. Sort matches by distance
    matches = sorted(matches, key=lambda x: x.distance)

    # 9. Select good matches (top 100)
    good_matches = matches[:100]

    # 10. Draw matched points
    matched_image = cv2.drawMatches(dots, keypoints_1, image_2, keypoints_2, good_matches, None, flags=2)
    cv2.imshow('Matches', matched_image)

    # 11. Parse matched points
    train_points = np.float32([keypoints_1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
    test_points = np.float32([keypoints_2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)

    # 12. Calculate the homography matrix
    M, mask = cv2.findHomography(train_points, test_points, cv2.RANSAC, 5.0)
    if M is not None:
        h, w = gray_1.shape
        pts = np.float32([[0, 0], [0, h - 1], [w - 1, h - 1], [w - 1, 0]]).reshape(-1, 1, 2)
        dst = cv2.perspectiveTransform(pts, M)

        # 13. draw the detection result（MUG）
        detection = cv2.polylines(image_2, [np.int32(dst)], True, (50, 0, 255), 3, cv2.LINE_AA)
        cv2.imshow('Mug Detection in ROS2.jpg', detection)
    else:
        print("Cannot find homography matrix.")

    # 14.wait for the request for closing
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
