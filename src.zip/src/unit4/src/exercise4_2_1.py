#!/usr/bin/env python
# exercise4_2_1.py

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2
import os

class CaptureWaterhole:
    def __init__(self):
        self.bridge = CvBridge()
        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw", Image, self.callback)
        self.captured = False
        self.save_path = '/home/user/catkin_ws/src/unit4/src/'  # Modify this to your path
        rospy.loginfo("CaptureWaterhole node initialized.")

    def callback(self, data):
        if self.captured:
            return

        try:
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            rospy.logerr(e)
            return

        # Display the image to select the waterhole region (optional)
        # cv2.imshow("Captured Image", cv_image)
        # cv2.waitKey(0)

        # Assume the coordinates of the waterhole region are known, and crop the image
        # You need to adjust the coordinates below based on your actual situation
        x, y, w, h = 100, 100, 200, 200  # Example coordinates
        waterhole = cv_image[y:y+h, x:x+w]

        # Save the cropped waterhole image
        cv2.imwrite(os.path.join(self.save_path, 'waterhole_cropped.png'), waterhole)
        rospy.loginfo("Waterhole image saved as 'waterhole_cropped.png'.")
        self.captured = True

        # Shut down the node
        rospy.signal_shutdown("Image captured and saved.")

def main():
    rospy.init_node('capture_waterhole_node', anonymous=True)
    capture = CaptureWaterhole()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        rospy.loginfo("Shutting down CaptureWaterhole node.")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
