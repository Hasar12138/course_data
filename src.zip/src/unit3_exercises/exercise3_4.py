#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2
import os
from datetime import datetime

class FaceDetector:
    def __init__(self):
        self.bridge = CvBridge()
        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw", Image, self.image_callback)
        
        # load Haar cascade classifier
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
        
        # create the directory to save the image
        self.save_dir = os.path.join(rospy.get_param('~save_path', default=os.path.expanduser('~')), 'unit3_exercises', 'captured_images')
        if not os.path.exists(self.save_dir):
            os.makedirs(self.save_dir)
        
        rospy.loginfo("FaceDetector initialized. Saving images to: {}".format(self.save_dir))

    def image_callback(self, data):
        try:
            # 将ROS图像消息转换为OpenCV图像
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            rospy.logerr(e)
            return

        # resize the image
        resized_image = cv2.resize(cv_image, (350, 550))
        
        # convert the image to grayscale
        gray = cv2.cvtColor(resized_image, cv2.COLOR_BGR2GRAY)
        
        # detect the face
        faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)
        
        for (x, y, w, h) in faces:
            # draw rectangles
            cv2.rectangle(resized_image, (x, y), (x+w, y+h), (255, 0, 0), 2)
            
            # extract the face
            roi_gray = gray[y:y+h, x:x+w]
            roi_color = resized_image[y:y+h, x:x+w]
            
            # detect eyes
            eyes = self.eye_cascade.detectMultiScale(roi_gray)
            for (ex, ey, ew, eh) in eyes:
                cv2.rectangle(roi_color, (ex, ey), (ex+ew, ey+eh), (0, 255, 0), 2)
            
            # save the detected image
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            image_name = "face_{}.jpg".format(timestamp)
            save_path = os.path.join(self.save_dir, image_name)
            cv2.imwrite(save_path, resized_image)
            rospy.loginfo("Saved image: {}".format(save_path))
        
        # display the real-time result
        cv2.imshow("Face Detection", resized_image)
        cv2.waitKey(1)

def main():
    rospy.init_node('exercise3_4', anonymous=True)
    fd = FaceDetector()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        rospy.loginfo("Shutting down")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
