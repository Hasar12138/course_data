#!/usr/bin/env python

import rospy
import numpy as np 
import cv2

def main():
    # Initialize ROS node
    rospy.init_node('exercise3_5_node', anonymous=True)
    
    #  Initialize HOG descriptor
    hog = cv2.HOGDescriptor()
    
    # Set HOG descriptor as pedestrian detector
    hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
    
    # Get the image path from the parameter server, use the default path if not set

    image_path = rospy.get_param('~image_path', '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_3/Course_images/test_e.jpg')
    
    #  read image: 
    img = cv2.imread(image_path)
    
    if img is None:
        rospy.logerr(" Unable to read image: %s: %s", image_path)
        return
    
    # Resize the image
    imX = 720
    imY = 1080
    img = cv2.resize(img, (imX, imY))
    
    #  Perform multi-scale detection using HOG
    boxes, weights = hog.detectMultiScale(img, winStride=(8,8))
    boxes = np.array([[x, y, x + w, y + h] for (x, y, w, h) in boxes])
    
    for (xA, yA, xB, yB) in boxes:
        
        # Calculate the X coordinate of the rectangle center
        medX = xB - xA 
        xC = int(xA + (medX / 2)) 
    
        # Calculate the Y coordinate of the rectangle center
        medY = yB - yA 
        yC = int(yA + (medY / 2)) 
    
        # Draw a circle at the center
        cv2.circle(img, (xC, yC), 1, (0, 255, 255), -1)
    
        # Draw the detected rectangle on the image
        cv2.rectangle(img, (xA, yA), (xB, yB), (255, 255, 0), 2)    
    
    # display the processed image
    cv2.imshow('Detected People', img)
    rospy.loginfo("Close the window by pressing any button")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
