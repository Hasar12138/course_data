#!/usr/bin/env python3

import rospy
import cv2
import os

def main():
    rospy.init_node('haar_cascade_my_photo_node', anonymous=True)

    # read the image(no images)
    image_path = '/home/user/catkin_ws/src/unit3_exercises/my_photo/my_photo.jpg'
    image = cv2.imread(image_path)

    if image is None:
        rospy.logerr("Fail to read the image：%s", image_path)
        return

    # resize the image
    resized_image = cv2.resize(image, (500, 300))

    
    gray = cv2.cvtColor(resized_image, cv2.COLOR_BGR2GRAY)

    # load the Haar-Cascade classifier
    face_cascade_path = '/home/user/catkin_ws/src/unit3_exercises/haar_cascades/frontalface.xml'
    eye_cascade_path = '/home/user/catkin_ws/src/unit3_exercises/haar_cascades/eye.xml'

    face_cascade = cv2.CascadeClassifier(face_cascade_path)
    eye_cascade = cv2.CascadeClassifier(eye_cascade_path)

    if face_cascade.empty():
        rospy.logerr("FAIL TO LOAD THE FILE(FACE)：%s", face_cascade_path)
        return

    if eye_cascade.empty():
        rospy.logerr("FAIL TO LOAD THE FILE(EYES)：%s", eye_cascade_path)
        return

    # detect the faces
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        # draw the rectangles
        cv2.rectangle(resized_image, (x, y), (x + w, y + h), (255, 0, 0), 2)

        roi_gray = gray[y:y + h, x:x + w]
        roi_color = resized_image[y:y + h, x:x + w]

        # detect eyes
        eyes = eye_cascade.detectMultiScale(roi_gray)
        for (ex, ey, ew, eh) in eyes:
            cv2.rectangle(roi_color, (ex, ey), (ex + ew, ey + eh), (0, 255, 0), 2)

    # display the result
    cv2.imshow('Detected Faces and Eyes', resized_image)
    cv2.imshow('Original Image', image)

    rospy.loginfo("Exit by pressing any button...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
