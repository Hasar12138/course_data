#!/usr/bin/env python3
# press 3 when picking one of the executable files
import rospy
import cv2

def main():
    rospy.init_node('haar_cascade_many_faces_node', anonymous=True)


    image_path = '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_3/Course_images/many.jpg'
    image = cv2.imread(image_path)

    if image is None:
        rospy.logerr("Fail to read the image：%s", image_path)
        return

  
    resized_image = cv2.resize(image, (700, 600))

  
    gray = cv2.cvtColor(resized_image, cv2.COLOR_BGR2GRAY)

   
    face_cascade_path = '/home/user/catkin_ws/src/unit3_exercises/haar_cascades/frontalface.xml'

    face_cascade = cv2.CascadeClassifier(face_cascade_path)

    if face_cascade.empty():
        rospy.logerr("Fail to load the file：%s", face_cascade_path)
        return

    # detect the faces
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        # draw the rectangles
        cv2.rectangle(resized_image, (x, y), (x + w, y + h), (255, 0, 0), 2)

    # Display the result
    cv2.imshow('Detected Faces', resized_image)
    cv2.imshow('Original Image', image)

    rospy.loginfo("Exit by pressing any button...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
