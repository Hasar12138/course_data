#!/usr/bin/env python

import rospy
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from skimage import feature, exposure

class VideoPersonTracker:

    def __init__(self):
        self.ctrl_c = False
        self.bridge = CvBridge()

        # Video file path
        self.video_path = "/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_3/Course_images/chris5-2.mp4"

        rospy.on_shutdown(self.shutdownhook)

    def shutdownhook(self):
        self.ctrl_c = True

    def track_person(self):
        # Load the video
        cap = cv2.VideoCapture(self.video_path)
        if not cap.isOpened():
            rospy.logerr("Error opening video stream or file.")
            return

        # Initialize HOG descriptor for person detection
        hog = cv2.HOGDescriptor()
        hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

        while not self.ctrl_c and cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                rospy.loginfo("End of video stream.")
                break

            # Resize the frame to reduce processing time (300x650)
            frame_resized = cv2.resize(frame, (300, 650))

            # Convert the frame to grayscale for HOG detection
            gray = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2GRAY)

            # Detect people using HOG
            (rects, weights) = hog.detectMultiScale(gray, winStride=(8, 8), padding=(8, 8), scale=1.05)

            # Draw bounding boxes around detected people
            for (x, y, w, h) in rects:
                cv2.rectangle(frame_resized, (x, y), (x + w, y + h), (0, 255, 0), 2)

            # Show the original video and the processed video with tracking
            cv2.imshow('Original Video', frame)
            cv2.imshow('Person Tracking', frame_resized)

            # Exit if 'q' is pressed
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    rospy.init_node('video_person_tracker_node', anonymous=True)
    video_tracker = VideoPersonTracker()

    try:
        video_tracker.track_person()
    except rospy.ROSInterruptException:
        pass
