#!/usr/bin/env python

import rospy
import cv2
import numpy as np
from skimage import exposure, feature

def main():
    # Initialize the ROS node
    rospy.init_node('exercise3_6_node', anonymous=True)
    
    # Get the image path from the ROS parameter server or use default
    image_path = rospy.get_param('~image_path', '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_3/Course_images/test_e.jpg')
    
    # Read the image
    img = cv2.imread(image_path)
    if img is None:
        rospy.logerr("Could not read image from path: %s", image_path)
        return
    
    # Resize image
    imX = 720
    imY = 1080
    img = cv2.resize(img, (imX, imY))
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Compute HOG features and visualize them
    (H, hogImage) = feature.hog(gray, orientations=9, pixels_per_cell=(8, 8),
                                cells_per_block=(2, 2), visualize=True)
    
    # Rescale HOG image to the range [0, 255]
    hogImage = exposure.rescale_intensity(hogImage, out_range=(0, 255))
    hogImage = hogImage.astype("uint8")
    
    # Display the HOG features
    cv2.imshow('HOG Features', hogImage)
    
    # Wait for a key press and close the window
    rospy.loginfo("Press any key to close the window.")
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
