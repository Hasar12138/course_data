#!/usr/bin/env python

import rospy
import cv2
import numpy as np
from skimage import exposure, feature
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

class PersonDetection():
    
    def __init__(self):
        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw", Image, self.image_callback)
        self.bridge = CvBridge()
        self.person_detected = False
        self.robot_height = 0.0
        self.cmd = None
        rospy.Subscriber("/sonar_height", Range, self.height_callback)
    
    def height_callback(self, msg):
        self.robot_height = msg.range

    def image_callback(self, msg):
        if self.robot_height > 1.96:  # Only detect when the height is greater than 1.96m
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            self.detect_person(cv_image)

    def detect_person(self, img):
        # Resize image to 700x500 for faster processing
        img = cv2.resize(img, (700, 500))
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Detect HOG features
        hog = cv2.HOGDescriptor()
        hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
        (rects, weights) = hog.detectMultiScale(gray, winStride=(8, 8), padding=(8, 8), scale=1.05)

        # Only continue if at least one person is detected
        if len(rects) > 0:
            self.person_detected = True
            rospy.loginfo("Human detected!")
            
            # Get the position of the first person detected
            (x, y, w, h) = rects[0]
            center_x = x + w // 2

            # Check if the person is on the left or right side
            if center_x < img.shape[1] // 2:
                rospy.loginfo("This person is on the left side.")
            else:
                rospy.loginfo("This person is on the right side.")

            # Draw rectangles and show the result
            for (x, y, w, h) in rects:
                cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)

            cv2.imshow("Human Detection", img)
            cv2.waitKey(1)
        else:
            rospy.loginfo("Nobody detected.")
            self.person_detected = False

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    rospy.init_node('person_detection_node', anonymous=True)
    person_detection = PersonDetection()
    person_detection.run()
