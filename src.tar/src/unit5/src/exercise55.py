#!/usr/bin/env python3
import rospy
import cv2
import numpy as np
from cv2 import aruco
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

def order_coordinates(pts, var):
    coordinates = np.zeros((4,2), dtype="int")

    if(var):
        # Parameters sort model 1 
        s = pts.sum(axis=1)
        coordinates[0] = pts[np.argmin(s)]
        coordinates[3] = pts[np.argmax(s)] 

        diff = np.diff(pts, axis=1)
        coordinates[1] = pts[np.argmin(diff)]
        coordinates[2] = pts[np.argmax(diff)]

    else:
        # Parameters sort model 2 
        s = pts.sum(axis=1)
        coordinates[0] = pts[np.argmin(s)]
        coordinates[2] = pts[np.argmax(s)] 

        diff = np.diff(pts, axis=1)
        coordinates[1] = pts[np.argmin(diff)]
        coordinates[3] = pts[np.argmax(diff)]

    return coordinates

class ArucoDetector:
    def __init__(self):
        rospy.init_node('exercise5_5_node', anonymous=True)

        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw", Image, self.image_callback)
        self.bridge = CvBridge()
        self.image_pub = rospy.Publisher("processed_image", Image, queue_size=1)

        # Initialize the ArUco dictionary and parameters
        self.aruco_dict = aruco.Dictionary_get(aruco.DICT_6X6_250)
        self.parameters = aruco.DetectorParameters_create()

    def image_callback(self, data):
        try:
            # Convert ROS Image message to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            rospy.logerr(e)
            return

        # Resize image
        h, w = cv_image.shape[:2]
        resized_image = cv2.resize(cv_image, (int(w*0.7), int(h*0.7)))
        gray = cv2.cvtColor(resized_image, cv2.COLOR_BGR2GRAY)

        # Detect ArUco markers
        corners, ids, rejectedImgPoints = aruco.detectMarkers(gray, self.aruco_dict, parameters=self.parameters)

        # Initialize an empty list for the coordinates
        params = []

        if ids is not None:
            for i in range(len(ids)):
                # Get the corners of each marker
                c = corners[i][0]

                # Draw a circle at the center of each detection
                center_x = int(c[:, 0].mean())
                center_y = int(c[:, 1].mean())
                cv2.circle(resized_image, (center_x, center_y), 3, (255, 255, 0), -1)

                # Save the coordinates of the center of each marker
                params.append((center_x, center_y))

            # Transform the coordinates list to a NumPy array
            params = np.array(params)

            # (可选) 排序坐标，示例中使用 model 1
            ordered_coords = order_coordinates(params, var=True)
            rospy.loginfo("Ordered Coordinates:\n{}".format(ordered_coords))
        else:
            rospy.loginfo("No ArUco markers detected.")

        # Publish the processed image
        try:
            self.image_pub.publish(self.bridge.cv2_to_imgmsg(resized_image, "bgr8"))
        except CvBridgeError as e:
            rospy.logerr(e)

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    try:
        detector = ArucoDetector()
        detector.run()
    except rospy.ROSInterruptException:
        pass
