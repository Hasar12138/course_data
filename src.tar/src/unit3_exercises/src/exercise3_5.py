#!/usr/bin/env python

import rospy
import numpy as np
import cv2
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

class HOGPersonDetector:
    def __init__(self):
        # Initialize ROS node
        rospy.init_node('exercise3_5', anonymous=True)

        # Create CvBridge object
        self.bridge = CvBridge()

        # Subscribe to the camera image topic (modify the topic name as needed)
        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw", Image, self.image_callback)

        # Publish the processed image
        self.image_pub = rospy.Publisher("/exercise3_5/processed_image", Image, queue_size=1)

        # Initialize HOG descriptor
        self.hog = cv2.HOGDescriptor()
        self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

        rospy.loginfo("HOG Person Detector node initialized.")

    def image_callback(self, data):
        try:
            # Convert ROS image message to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            rospy.logerr("CvBridge Error: {}".format(e))
            return

        # Resize the image (modify the dimensions as needed)
        imX = 720
        imY = 1080
        img_resized = cv2.resize(cv_image, (imX, imY))

        # Use HOG descriptor to detect people
        boxes, weights = self.hog.detectMultiScale(img_resized, winStride=(8,8))

        # Convert detection results format
        boxes = np.array([[x, y, x + w, y + h] for (x, y, w, h) in boxes])

        for (xA, yA, xB, yB) in boxes:
            # Calculate the center point
            medX = xB - xA 
            xC = int(xA + (medX / 2)) 

            medY = yB - yA 
            yC = int(yA + (medY / 2)) 

            # Draw a circle at the center point
            cv2.circle(img_resized, (xC, yC), 5, (0, 255, 255), -1)

            # Draw a rectangle around the detected person
            cv2.rectangle(img_resized, (xA, yA), (xB, yB), (255, 255, 0), 2)    

        # Publish the processed image to a new topic
        try:
            self.image_pub.publish(self.bridge.cv2_to_imgmsg(img_resized, "bgr8"))
        except CvBridgeError as e:
            rospy.logerr("CvBridge Error: {}".format(e))

        # Optional: Display the image locally (for debugging only, not recommended for long-term use in ROS nodes)
        cv2.imshow("HOG Person Detection", img_resized)
        cv2.waitKey(1)

    def run(self):
        rospy.spin()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        detector = HOGPersonDetector()
        detector.run()
    except rospy.ROSInterruptException:
        pass
