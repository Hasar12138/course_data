#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
import os

def main():
    rospy.init_node('exercise_3_1', anonymous=True)
    bridge = CvBridge()

    # 图像路径
    image_path = '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_3/Course_images/chris.jpg'

    if not os.path.exists(image_path):
        rospy.logerr("图像文件不存在: {}".format(image_path))
        return

    # 读取图像
    img = cv2.imread(image_path)
    if img is None:
        rospy.logerr("无法读取图像文件: {}".format(image_path))
        return

    # 调整图像大小
    resized_img = cv2.resize(img, (500, 300))

    # 加载 Haar Cascade 分类器
    cascade_path_face = os.path.join(os.path.dirname(__file__), '..', 'haar_cascades', 'frontalface.xml')
    cascade_path_eye = os.path.join(os.path.dirname(__file__), '..', 'haar_cascades', 'eye.xml')

    if not os.path.exists(cascade_path_face):
        rospy.logerr("Haar Cascade 文件不存在: {}".format(cascade_path_face))
        return

    if not os.path.exists(cascade_path_eye):
        rospy.logerr("Haar Cascade 文件不存在: {}".format(cascade_path_eye))
        return

    face_cascade = cv2.CascadeClassifier(cascade_path_face)
    eye_cascade = cv2.CascadeClassifier(cascade_path_eye)

    if face_cascade.empty():
        rospy.logerr("无法加载人脸检测分类器")
        return

    if eye_cascade.empty():
        rospy.logerr("无法加载眼睛检测分类器")
        return

    # 转为灰度图
    gray = cv2.cvtColor(resized_img, cv2.COLOR_BGR2GRAY)

    # 检测人脸
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        # 在人脸周围绘制矩形
        cv2.rectangle(resized_img, (x, y), (x + w, y + h), (255, 0, 0), 2)
        roi_gray = gray[y:y + h, x:x + w]
        roi_color = resized_img[y:y + h, x:x + w]

        # 检测眼睛
        eyes = eye_cascade.detectMultiScale(roi_gray)
        for (ex, ey, ew, eh) in eyes:
            cv2.rectangle(roi_color, (ex, ey), (ex + ew, ey + eh), (0, 255, 0), 2)

    # 显示原始图像和处理后的图像
    cv2.imshow('Original Image', img)
    cv2.imshow('Processed Image', resized_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
