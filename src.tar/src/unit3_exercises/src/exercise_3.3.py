#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import cv2
import os
import sys

def main():
    # initialize the node
    rospy.init_node('exercise_3_3', anonymous=True)

    # image's path
    image_path = '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_3/Course_images/many.jpg'

    # Check if the image exists
    if not os.path.exists(image_path):
        rospy.logerr("The image does not exist: {}".format(image_path))
        sys.exit(1)

    # read an image
    img = cv2.imread(image_path)
    if img is None:
        rospy.logerr("Fail to read the image: {}".format(image_path))
        sys.exit(1)

    # resize images to 700x600
    resized_img = cv2.resize(img, (700, 600))

    # load Haar Cascade Classifier
    cascade_path_face = '/home/user/catkin_ws/src/unit3_exercises/haar_cascades/frontalface.xml'

    if not os.path.exists(cascade_path_face):
        rospy.logerr("Haar Cascade does not exist: {}".format(cascade_path_face))
        sys.exit(1)

    face_cascade = cv2.CascadeClassifier(cascade_path_face)

    if face_cascade.empty():
        rospy.logerr("Fail to load Haar Cascade classifier")
        sys.exit(1)

    # Convert to grayscale
    gray = cv2.cvtColor(resized_img, cv2.COLOR_BGR2GRAY)

    # detect faces
    scale_factor = 1.2
    min_neighbors = 3
    faces = face_cascade.detectMultiScale(gray, scaleFactor=scale_factor, minNeighbors=min_neighbors)

    # Draw rectangles around detected faces
    for (x, y, w, h) in faces:
        cv2.rectangle(resized_img, (x, y), (x + w, y + h), (255, 255, 0), 2)
        roi = resized_img[y:y + h, x:x + w]

    
# Display original and processed images
    cv2.imshow('Original Image', img)
    cv2.imshow('Detected Faces', resized_img)

    rospy.loginfo("Close all windows by pressing any button")
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
