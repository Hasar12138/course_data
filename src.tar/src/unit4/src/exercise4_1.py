#!/usr/bin/env python
# -*- coding: utf-8 -*-

import cv2
import matplotlib.pyplot as plt
import numpy as np

def main():
    # Read the first image and resize to 400x600
    image_1_path = '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_4/Course_images/ROS.jpg'
    image_1 = cv2.imread(image_1_path, 1)
    if image_1 is None:
        print("Cannot read image:", image_1_path)
        return
    image_1 = cv2.resize(image_1, (600, 400))  # Width x Height

    # Read the second image and resize to 600x400
    image_2_path = '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_4/Course_images/ROS2.jpg'
    image_2 = cv2.imread(image_2_path, 1)
    if image_2 is None:
        print("Cannot read image:", image_2_path)
        return
    image_2 = cv2.resize(image_2, (600, 400))  # Width x Height

    # Convert images to grayscale
    gray_1 = cv2.cvtColor(image_1, cv2.COLOR_BGR2GRAY)
    gray_2 = cv2.cvtColor(image_2, cv2.COLOR_BGR2GRAY)

    # Initialize ORB feature detector
    orb = cv2.ORB_create(nfeatures=1000)

    # Extract keypoints and descriptors
    keypoints_1, descriptors_1 = orb.detectAndCompute(gray_1, None)
    keypoints_2, descriptors_2 = orb.detectAndCompute(gray_2, None)

    # Draw keypoints of ROS.png
    preview_1 = cv2.drawKeypoints(image_1, keypoints_1, None, flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    cv2.imshow('ROS.jpg - Keypoints', preview_1)

    # Initialize brute-force matcher
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

    # Match descriptors
    matches = bf.match(descriptors_1, descriptors_2)

    # Sort by distance
    matches = sorted(matches, key=lambda x: x.distance)

    # Select the top 100 good matches
    good_matches = matches[:100]

    # Draw matches
    matches_img = cv2.drawMatches(image_1, keypoints_1, image_2, keypoints_2, good_matches, None, flags=2)
    cv2.imshow('Matches', matches_img)

    # Extract location of matched points
    src_pts = np.float32([keypoints_1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
    dst_pts = np.float32([keypoints_2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)

    # Compute homography matrix
    M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
    if M is not None:
        h, w = gray_1.shape
        pts = np.float32([[0, 0], [0, h-1], [w-1, h-1], [w-1, 0]]).reshape(-1, 1, 2)
        dst = cv2.perspectiveTransform(pts, M)

        # Draw detection result (e.g., a mug) on the second image
        detection_img = cv2.polylines(image_2.copy(), [np.int32(dst)], True, (50, 0, 255), 3, cv2.LINE_AA)
        cv2.imshow('Mug Detection in ROS2.png', detection_img)
    else:
        print("Cannot find homography matrix.")

    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
