#!/usr/bin/env python

import rospy
import cv2
import numpy as np

# Initialize the ROS node
rospy.init_node('color_filter', anonymous=True)

# Read the image from the given path
image_path = '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_2/Course_images/Filtering.png'
image = cv2.imread(image_path)

if image is None:
    rospy.logerr("Error: Image not found at path: %s", image_path)
    exit()

# Resize the image
image = cv2.resize(image, (300, 300))

# Convert image to HSV color space
hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# Define HSV ranges for colors
min_green = np.array([50, 220, 220])
max_green = np.array([60, 255, 255])

min_red = np.array([170, 220, 220])
max_red = np.array([180, 255, 255])

min_blue = np.array([110, 220, 220])
max_blue = np.array([120, 255, 255])

# Create masks for each color
mask_g = cv2.inRange(hsv, min_green, max_green)
mask_r = cv2.inRange(hsv, min_red, max_red)
mask_b = cv2.inRange(hsv, min_blue, max_blue)

# Apply the masks to the original image
res_g = cv2.bitwise_and(image, image, mask=mask_g)
res_r = cv2.bitwise_and(image, image, mask=mask_r)
res_b = cv2.bitwise_and(image, image, mask=mask_b)

# Display the original image and filtered results
cv2.imshow('Original Image', image)
cv2.imshow('Filtered Green', res_g)
cv2.imshow('Filtered Red', res_r)
cv2.imshow('Filtered Blue', res_b)

# Keep the windows open until the user closes them
cv2.waitKey(0)
cv2.destroyAllWindows()

# ROS spin to keep the node running
rospy.spin()
