#!/usr/bin/env python
import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2
import os

# Initialize the CvBridge class
bridge = CvBridge()

# Callback function to display the real-time camera image
def camera_callback(msg):
    try:
        # Convert ROS Image message to OpenCV format
        live_frame = bridge.imgmsg_to_cv2(msg, "bgr8")
        
        # Display the live camera image
        cv2.imshow('Live Camera Image', live_frame)
        cv2.waitKey(1)  # Refresh window
    except CvBridgeError as e:
        rospy.logerr("Error converting live camera image: %s", str(e))

def main():
    rospy.init_node('load_image2_node', anonymous=True)

    # Load the saved drone image
    drone_image_path = '/home/user/catkin_ws/src/unit2/src/drone_image.jpg'
    if os.path.exists(drone_image_path):
        drone_image = cv2.imread(drone_image_path)
        cv2.imshow('Drone Image', drone_image)
        cv2.waitKey(1)  # Keep the window open
    else:
        rospy.logerr("Error: Saved image not found at path: %s", drone_image_path)

    # Subscribe to the live camera feed
    rospy.Subscriber('/camera/rgb/image_raw', Image, camera_callback)

    # Keep the script running
    rospy.spin()

    # Close all OpenCV windows
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
