#!/usr/bin/env python

import cv2
import rospy

def main():
    rospy.init_node('sobela_node')

    # Clear all previously opened image windows
    cv2.destroyAllWindows()

    # Load the image from the correct path
    image_path = '/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_2/Course_images/test_img_b.jpg'
    img = cv2.imread(image_path)

    # Check if the image was loaded correctly
    if img is None:
        rospy.logerr("Failed to load image. Please check the image path.")
        return

    # Convert the image to grayscale for better edge detection
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img_resized = cv2.resize(img_gray, (450, 350))

    # Apply the Sobel operator (edge detection)
    sobelx = cv2.Sobel(img_resized, cv2.CV_64F, 1, 0, ksize=3)  # Horizontal gradient
    sobely = cv2.Sobel(img_resized, cv2.CV_64F, 0, 1, ksize=3)  # Vertical gradient

    # Display the original and filtered images
    cv2.imshow('Original Image (test_img_b.jpg)', img_resized)
    cv2.imshow('Sobel X (Horizontal Edges)', sobelx)
    cv2.imshow('Sobel Y (Vertical Edges)', sobely)

    # Wait for key press or a small delay to refresh windows
    cv2.waitKey(1)

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
