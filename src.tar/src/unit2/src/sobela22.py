#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

class SobelA2:
    def __init__(self):
        self.bridge = CvBridge()
        # Subscribe to the image topic published by usb_cam
        self.image_sub = rospy.Subscriber("/usb_cam/image_raw", Image, self.callback)
        
        # Create windows
        cv2.namedWindow("Original Image", cv2.WINDOW_NORMAL)
        cv2.namedWindow("Gray Image with Sobel", cv2.WINDOW_NORMAL)

    def callback(self, data):
        try:
            # Convert ROS image message to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            rospy.logerr(e)
            return

        # Convert to grayscale image
        gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

        # Apply horizontal Sobel operator
        sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobelx = cv2.convertScaleAbs(sobelx)

        # Apply vertical Sobel operator
        sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        sobely = cv2.convertScaleAbs(sobely)

        # Combine horizontal and vertical results
        sobel_combined = cv2.addWeighted(sobelx, 0.5, sobely, 0.5, 0)

        # Display images
        cv2.imshow("Original Image", cv_image)
        cv2.imshow("Gray Image with Sobel", sobel_combined)
        cv2.waitKey(1)

def main():
    rospy.init_node('sobela2_node', anonymous=True)
    sobel_a2 = SobelA2()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        rospy.loginfo("Shutting down")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
