#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import cv2
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image

class MorphologicalTransformations:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('morphological_transformations_node', anonymous=True)
        rospy.loginfo("Morphological Transformations Node has started")

        # Create a CvBridge object for converting ROS images to OpenCV images
        self.bridge = CvBridge()

        # Load the image
        self.image_path = "/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_2/Course_images/world.png"
        self.original_image = cv2.imread(self.image_path)
        if self.original_image is None:
            rospy.logerr(f"Cannot read image: {self.image_path}")
            rospy.signal_shutdown("Image not found or cannot be read.")
            return

        # Resize the image for consistent display
        self.resized_image = cv2.resize(self.original_image, (600, 400))

        # Convert to grayscale
        self.gray_image = cv2.cvtColor(self.resized_image, cv2.COLOR_BGR2GRAY)

        # Define a kernel for morphological operations
        self.kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))

        # Apply morphological operations
        self.apply_morphological_filters()

        # Display all images
        self.display_images()

    def apply_morphological_filters(self):
        # Erosion
        self.eroded = cv2.erode(self.gray_image, self.kernel, iterations=1)

        # Dilation
        self.dilated = cv2.dilate(self.gray_image, self.kernel, iterations=1)

        # Opening (Erosion followed by Dilation)
        self.opening = cv2.morphologyEx(self.gray_image, cv2.MORPH_OPEN, self.kernel)

        # Closing (Dilation followed by Erosion)
        self.closing = cv2.morphologyEx(self.gray_image, cv2.MORPH_CLOSE, self.kernel)

        # Morphological Gradient
        self.gradient = cv2.morphologyEx(self.gray_image, cv2.MORPH_GRADIENT, self.kernel)

        # Top Hat
        self.top_hat = cv2.morphologyEx(self.gray_image, cv2.MORPH_TOPHAT, self.kernel)

        # Black Hat
        self.black_hat = cv2.morphologyEx(self.gray_image, cv2.MORPH_BLACKHAT, self.kernel)

    def display_images(self):
        # Create window names
        window_names = [
            "Original Image",
            "Gray Image",
            "Eroded Image",
            "Dilated Image",
            "Opening",
            "Closing",
            "Morphological Gradient",
            "Top Hat",
            "Black Hat"
        ]

        # Create a list of images to display
        images = [
            self.resized_image,
            self.gray_image,
            self.eroded,
            self.dilated,
            self.opening,
            self.closing,
            self.gradient,
            self.top_hat,
            self.black_hat
        ]

        # Display each image in its own window
        for name, img in zip(window_names, images):
            cv2.imshow(name, img)

        rospy.loginfo("Displaying all morphological transformations. Press 'q' to exit.")

        # Wait until 'q' is pressed
        while not rospy.is_shutdown():
            if cv2.waitKey(1) & 0xFF == ord('q'):
                rospy.signal_shutdown("User requested shutdown.")
                break

        # Destroy all OpenCV windows upon shutdown
        cv2.destroyAllWindows()

    def run(self):
        try:
            rospy.spin()
        except KeyboardInterrupt:
            rospy.loginfo("Shutting down Morphological Transformations Node")
        finally:
            cv2.destroyAllWindows()

if __name__ == '__main__':
    transformations_node = MorphologicalTransformations()
    transformations_node.run()
