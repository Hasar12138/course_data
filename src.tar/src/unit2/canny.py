#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import cv2
import numpy as np

# Load the image
img = cv2.imread('/home/user/catkin_ws/src/opencv_for_robotics_images/Unit_2/Course_images/test_img.png')

# Resize the image to a specific width and height
img = cv2.resize(img, (450, 350))

# Define the minimum and maximum intensity gradients for the Canny detector
minV = 30
maxV = 100

# Apply Canny edge detection to the image
edges = cv2.Canny(img, minV, maxV)

# Display the original image and the detected edges
cv2.imshow('Original', img)
cv2.imshow('Canny Edges', edges)

# Wait for a key press and close all windows
cv2.waitKey(0)
cv2.destroyAllWindows()
