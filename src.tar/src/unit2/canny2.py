#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2

class CannyEdgeDetector:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('canny_edge_detector_node', anonymous=True)
        rospy.loginfo("Canny Edge Detector Node has started")

        # Create a CvBridge object for converting ROS images to OpenCV images
        self.bridge = CvBridge()

        # Subscribe to the camera image topic
        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw", Image, self.image_callback)

    def image_callback(self, data):
        try:
            # Convert ROS Image message to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(data, desired_encoding="bgr8")
        except CvBridgeError as e:
            rospy.logerr(f"CvBridge Error: {e}")
            return

        # Resize the image for consistent display
        resized_image = cv2.resize(cv_image, (450, 350))

        # Convert to grayscale
        gray_image = cv2.cvtColor(resized_image, cv2.COLOR_BGR2GRAY)

        # Define the minimum and maximum intensity gradients for the Canny detector
        min_threshold = 30
        max_threshold = 100

        # Apply Canny edge detection
        edges = cv2.Canny(gray_image, min_threshold, max_threshold)

        # Display the original and edge-detected images
        cv2.imshow('Original Image', resized_image)
        cv2.imshow('Canny Edges', edges)

        # Wait for a short period to allow image display
        cv2.waitKey(1)

    def run(self):
        try:
            rospy.spin()
        except KeyboardInterrupt:
            rospy.loginfo("Shutting down Canny Edge Detector Node")
        finally:
            cv2.destroyAllWindows()

if __name__ == '__main__':
    detector = CannyEdgeDetector()
    detector.run()
