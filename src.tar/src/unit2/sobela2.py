#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

def main():
    # initialize the node
    rospy.init_node('sobel_a2_node', anonymous=True)

    # create the CvBridge bridge
    bridge = CvBridge()

    # Open the camera（The default index is 0）
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        rospy.logerr("Failed to open")
        return

    rospy.loginfo("Sobel A2 has been activated. Please exit by pressing q")

    while not rospy.is_shutdown():
        # capture frame by frame
        ret, frame = cap.read()

        if not ret:
            rospy.logerr("Unable to receive the frame. Exiting")
            break

        # convert the image to grayscale image
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # horizontal Sobel
        sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        # 绝对值转换并转换回uint8
        sobelx = cv2.convertScaleAbs(sobelx)

        # vertical Sobel
        sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        # 绝对值转换并转换回uint8
        sobely = cv2.convertScaleAbs(sobely)

        # combine the horizontal and vertical results
        sobel_combined = cv2.addWeighted(sobelx, 0.5, sobely, 0.5, 0)

        # show the original and processed image
        cv2.imshow('Original', frame)
        cv2.imshow('Sobel - Horizontal', sobelx)
        cv2.imshow('Sobel - Vertical', sobely)
        cv2.imshow('Sobel Combined', sobel_combined)

        # press'q' and quit
        if cv2.waitKey(1) & 0xFF == ord('q'):
            rospy.signal_shutdown("REQUEST FOR QUIT")
            break

    # release the camera
    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
